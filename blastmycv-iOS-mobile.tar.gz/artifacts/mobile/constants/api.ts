// Production API — blastmycv.com PHP backend
// Can be overridden with EXPO_PUBLIC_API_URL for local development
const LIVE_API_URL = "https://blastmycv.com/api";

export const API_BASE_URL = process.env.EXPO_PUBLIC_API_URL ?? LIVE_API_URL;

export const ENDPOINTS = {
  auth: {
    login: "/auth/login",
    register: "/auth/register",
    forgotPassword: "/auth/forgot-password",
    logout: "/auth/logout",
    me: "/auth/me",
  },
  user: {
    profile: "/user/profile",
    changePassword: "/user/change-password",
  },
  cvs: "/cvs",
  packages: "/packages",
  orders: "/orders",
  submissions: "/submissions",
  notifications: "/notifications",
  support: {
    contact: "/support/contact",
  },
};
